import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { motion } from "motion/react";
import { Menu, X, Globe, ArrowUpRight } from "lucide-react";
import { Logo } from "./Logo";
import { navLinks, SITE } from "@/lib/site";

export function Navbar() {
  const { t, i18n } = useTranslation();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const toggleLang = () => {
    const next = i18n.language?.startsWith("ar") ? "en" : "ar";
    i18n.changeLanguage(next);
  };

  return (
    <motion.header
      initial={{ y: -24, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled ? "py-2" : "py-4"
      }`}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div
          className={`flex items-center justify-between gap-4 rounded-full px-3 py-2 transition-all duration-300 sm:px-4 ${
            scrolled ? "glass shadow-elev" : "border border-white/5 bg-white/[0.02] backdrop-blur-md"
          }`}
        >
          <a href="#top" className="shrink-0">
            <Logo />
          </a>

          <nav className="hidden items-center gap-0.5 rounded-full border border-white/5 bg-white/[0.03] p-1 lg:flex">
            {navLinks.map((l) => (
              <a
                key={l.id}
                href={`#${l.id}`}
                className="rounded-full px-3.5 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-white/5 hover:text-foreground"
              >
                {t(l.key)}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-1.5">
            <button
              onClick={toggleLang}
              className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-foreground/80 transition-colors hover:border-gold/40 hover:text-foreground"
              aria-label="Toggle language"
            >
              <Globe className="h-3.5 w-3.5" />
              {i18n.language?.startsWith("ar") ? "EN" : "ع"}
            </button>
            <a
              href="#contact"
              className="group hidden items-center gap-1.5 rounded-full bg-gold px-4 py-2 text-sm font-semibold text-navy-deep shadow-gold transition-transform hover:scale-[1.02] sm:inline-flex"
            >
              {t("nav.quote")}
              <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </a>
            <button
              onClick={() => setOpen((v) => !v)}
              className="grid h-9 w-9 place-items-center rounded-full text-foreground lg:hidden"
              aria-label="Menu"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-2 grid gap-1 rounded-3xl glass p-3 shadow-elev lg:hidden"
          >
            {navLinks.map((l) => (
              <a
                key={l.id}
                href={`#${l.id}`}
                onClick={() => setOpen(false)}
                className="rounded-xl px-3 py-2 text-sm font-medium text-foreground hover:bg-white/5"
              >
                {t(l.key)}
              </a>
            ))}
            <a
              href={SITE.whatsapp}
              target="_blank"
              rel="noreferrer"
              className="mt-1 rounded-xl bg-gold px-3 py-2 text-center text-sm font-semibold text-navy-deep"
            >
              {t("nav.quote")}
            </a>
          </motion.div>
        )}
      </div>
    </motion.header>
  );
}