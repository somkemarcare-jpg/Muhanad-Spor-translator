import { useTranslation } from "react-i18next";
import { motion } from "motion/react";
import { ArrowRight, MessageCircle, ShieldCheck, Sparkles, Clock, Star } from "lucide-react";
import { SITE } from "@/lib/site";
import heroArt from "@/assets/hero-illustration.jpg";

export function Hero() {
  const { t } = useTranslation();
  return (
    <section id="top" className="relative isolate overflow-hidden bg-hero noise">
      {/* Layered glow orbs */}
      <div className="pointer-events-none absolute -top-40 -left-32 h-[640px] w-[640px] rounded-full bg-electric/25 blur-[140px] animate-float-slow" />
      <div className="pointer-events-none absolute top-20 right-[-15%] h-[560px] w-[560px] rounded-full bg-royal/30 blur-[140px] animate-float-slower" />
      <div className="pointer-events-none absolute bottom-[-20%] left-1/3 h-[500px] w-[500px] rounded-full bg-cyan-soft/15 blur-[120px] animate-float-slow" />
      {/* Grid texture */}
      <div className="pointer-events-none absolute inset-0 opacity-[0.05] [background-image:linear-gradient(to_right,white_1px,transparent_1px),linear-gradient(to_bottom,white_1px,transparent_1px)] [background-size:64px_64px] [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_75%)]" />
      <div className="noise-overlay" />

      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-4 pb-28 pt-36 sm:px-6 lg:grid-cols-12 lg:gap-10 lg:pb-40 lg:pt-44">
        {/* Left: copy */}
        <div className="lg:col-span-7">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex w-fit items-center gap-2 rounded-full glass-card px-4 py-1.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-foreground/80"
          >
            <span className="relative grid h-1.5 w-1.5 place-items-center">
              <span className="absolute h-2 w-2 rounded-full bg-gold/40 animate-pulse-glow" />
              <span className="relative h-1.5 w-1.5 rounded-full bg-gold" />
            </span>
            {t("hero.eyebrow")}
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 28 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.05, ease: [0.22, 1, 0.36, 1] }}
            className="font-display mt-7 text-[clamp(2.75rem,7vw,6.25rem)] font-normal leading-[0.98] tracking-[-0.02em]"
          >
            <span className="text-hero-grad">{t("hero.title1")}</span>
            <br />
            <span className="italic text-royal-grad">{t("hero.title2")}</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-8 max-w-xl text-lg leading-relaxed text-muted-foreground"
          >
            {t("hero.subtitle")}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.32 }}
            className="mt-10 flex flex-wrap items-center gap-3"
          >
            <a
              href="#contact"
              className="group relative inline-flex items-center gap-2 overflow-hidden rounded-full bg-gold px-7 py-3.5 text-sm font-semibold text-navy-deep shadow-gold transition-transform hover:scale-[1.03]"
            >
              <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/50 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
              <span className="relative">{t("hero.primary")}</span>
              <ArrowRight className="relative h-4 w-4 transition-transform group-hover:translate-x-0.5 rtl:rotate-180 rtl:group-hover:-translate-x-0.5" />
            </a>
            <a
              href={SITE.whatsapp}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-6 py-3.5 text-sm font-semibold text-foreground backdrop-blur transition-colors hover:border-gold/40 hover:bg-white/[0.08]"
            >
              <MessageCircle className="h-4 w-4 text-gold" />
              {t("hero.secondary")}
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="mt-12 flex flex-wrap items-center gap-x-7 gap-y-3 text-[13px] text-muted-foreground"
          >
            <span className="inline-flex items-center gap-2"><Sparkles className="h-4 w-4 text-gold" />{t("hero.badge1")}</span>
            <span className="inline-flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-gold" />{t("hero.badge2")}</span>
            <span className="inline-flex items-center gap-2"><Clock className="h-4 w-4 text-gold" />{t("hero.badge3")}</span>
          </motion.div>
        </div>

        {/* Right: illustration + floating cards */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto w-full max-w-md lg:col-span-5 lg:max-w-none"
        >
          {/* Outer glow */}
          <div className="absolute -inset-10 rounded-[3rem] bg-gradient-to-br from-electric/40 via-royal/30 to-gold/20 opacity-70 blur-3xl" />
          {/* Frame */}
          <div className="relative aspect-[4/5] overflow-hidden rounded-[2rem] border border-white/10 bg-navy-deep shadow-elev">
            <img
              src={heroArt}
              alt="Abstract translation between Arabic and English"
              width={1280}
              height={1280}
              loading="eager"
              className="h-full w-full scale-110 object-cover transition-transform duration-[1200ms] hover:scale-100"
            />
            {/* Top tint */}
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-navy-deep/80 via-transparent to-navy-deep/20" />
            {/* Inner ring */}
            <div className="pointer-events-none absolute inset-0 rounded-[2rem] ring-1 ring-inset ring-white/10" />

            {/* Caption inside */}
            <div className="absolute inset-x-0 bottom-0 p-6 sm:p-7">
              <div className="font-display text-2xl font-medium text-white">
                <span className="text-hero-grad">ع</span>
                <span className="mx-3 text-white/40">⇄</span>
                <span className="text-hero-grad">A</span>
              </div>
              <p className="mt-1 text-xs uppercase tracking-[0.28em] text-white/60">Native bilingual precision</p>
            </div>
          </div>

          {/* Floating glass card — rating */}
          <motion.div
            initial={{ opacity: 0, y: 20, x: -10 }}
            animate={{ opacity: 1, y: 0, x: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="absolute -left-4 top-10 hidden rounded-2xl glass-card p-3 pr-4 backdrop-blur sm:flex sm:items-center sm:gap-3 rtl:-right-4 rtl:left-auto"
          >
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-gold/15 text-gold">
              <Star className="h-4 w-4 fill-gold" />
            </div>
            <div className="leading-tight">
              <div className="text-sm font-semibold text-foreground">5.0 / 5.0</div>
              <div className="text-[11px] text-muted-foreground">Client reviews</div>
            </div>
          </motion.div>

          {/* Floating glass card — projects */}
          <motion.div
            initial={{ opacity: 0, y: 20, x: 10 }}
            animate={{ opacity: 1, y: 0, x: 0 }}
            transition={{ duration: 0.8, delay: 0.7 }}
            className="absolute -bottom-6 -right-4 hidden rounded-2xl glass-card p-4 pr-5 backdrop-blur sm:block rtl:-left-4 rtl:right-auto"
          >
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-electric/20 text-electric">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <div className="text-xs leading-tight">
                <div className="text-sm font-semibold text-foreground">2,500+ projects</div>
                <div className="text-[11px] text-muted-foreground">Delivered on time</div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Marquee-style trust strip */}
      <div className="relative border-y border-white/5 bg-black/20 backdrop-blur-sm">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-6 px-4 py-6 text-[11px] uppercase tracking-[0.28em] text-muted-foreground sm:px-6">
          <span className="text-foreground/70">{t("trust.title")}</span>
          <div className="flex flex-wrap items-center gap-x-8 gap-y-2 font-display text-base normal-case tracking-normal text-foreground/40">
            <span>Law Firms</span>
            <span className="hidden text-gold/40 sm:inline">✦</span>
            <span>Hospitals</span>
            <span className="hidden text-gold/40 sm:inline">✦</span>
            <span>Universities</span>
            <span className="hidden text-gold/40 sm:inline">✦</span>
            <span>Embassies</span>
            <span className="hidden text-gold/40 sm:inline">✦</span>
            <span>Multinationals</span>
          </div>
        </div>
      </div>
    </section>
  );
}