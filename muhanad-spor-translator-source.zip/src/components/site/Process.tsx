import { useTranslation } from "react-i18next";
import { motion } from "motion/react";
import { Eyebrow } from "./Eyebrow";

export function Process() {
  const { t } = useTranslation();
  const steps = t("process.steps", { returnObjects: true }) as { t: string; d: string }[];
  return (
    <section id="process" className="py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Eyebrow>{t("process.eyebrow")}</Eyebrow>
          <h2 className="font-display mt-5 text-4xl font-medium leading-[1.05] tracking-tight sm:text-5xl">
            {t("process.title")}
          </h2>
        </div>

        <div className="relative mt-16">
          <div className="absolute left-1/2 top-0 hidden h-full w-px -translate-x-1/2 bg-gradient-to-b from-transparent via-border to-transparent md:block" />
          <ol className="space-y-10">
            {steps.map((s, i) => (
              <motion.li
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.5, delay: i * 0.06 }}
                className={`relative grid grid-cols-1 items-center gap-6 md:grid-cols-2 md:gap-12 ${
                  i % 2 === 1 ? "md:[&>*:first-child]:order-2" : ""
                }`}
              >
                <div className={i % 2 === 1 ? "md:text-right rtl:md:text-left" : "md:text-left rtl:md:text-right"}>
                  <span className="font-display text-7xl font-light leading-none text-gold/30">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                </div>
                <div className="rounded-2xl border border-border bg-card p-7 shadow-soft">
                  <div className="mb-3 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-gold">
                    Step {i + 1}
                  </div>
                  <h3 className="font-display text-2xl font-medium tracking-tight">{s.t}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.d}</p>
                </div>
              </motion.li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}