export function Logo({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <span className="relative grid h-10 w-10 place-items-center overflow-hidden rounded-xl">
        {/* Monogram */}
        <span className="absolute inset-0 bg-royal" />
        <span className="absolute inset-0 opacity-60 [background:radial-gradient(120%_120%_at_20%_0%,oklch(0.92_0.09_92/0.6),transparent_55%)]" />
        <span className="absolute inset-px rounded-[10px] border border-white/15" />
        <svg viewBox="0 0 40 40" className="relative h-6 w-6 text-white" fill="none" aria-hidden="true">
          {/* Stylised "MS" monogram */}
          <path d="M6 30V12l7 12 7-12v18" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M34 14c0-1.5-2-3-5-3s-5 1.2-5 3.2c0 4 10 3.8 10 7.8 0 2-2 3-5 3s-5-1.2-5-3" stroke="oklch(0.92_0.09_92)" strokeWidth="2.2" strokeLinecap="round" />
        </svg>
        <span className="absolute -bottom-0.5 -right-0.5 h-1.5 w-1.5 rounded-full bg-gold shadow-gold" />
      </span>
      <span className="flex flex-col leading-none">
        <span className="font-display text-[17px] font-medium tracking-tight text-foreground">
          Muhanad <span className="italic text-hero-grad">Spor</span>
        </span>
        <span className="mt-1 text-[9px] font-semibold uppercase tracking-[0.28em] text-muted-foreground">
          Arabic <span className="text-gold">·</span> English Translation
        </span>
      </span>
    </span>
  );
}