import { useTranslation } from "react-i18next";
import { motion } from "motion/react";
import { Hand, Star, Tag, Zap, Lock, MessageSquare, DollarSign, Eye } from "lucide-react";
import { Eyebrow } from "./Eyebrow";

const items = [
  { k: "human", Icon: Hand },
  { k: "native", Icon: Star },
  { k: "terms", Icon: Tag },
  { k: "fast", Icon: Zap },
  { k: "conf", Icon: Lock },
  { k: "comm", Icon: MessageSquare },
  { k: "price", Icon: DollarSign },
  { k: "detail", Icon: Eye },
] as const;

export function WhyMe() {
  const { t } = useTranslation();
  return (
    <section className="bg-muted/40 py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Eyebrow>{t("why.eyebrow")}</Eyebrow>
          <h2 className="font-display mt-5 text-4xl font-medium leading-[1.05] tracking-tight sm:text-5xl">
            {t("why.title")}
          </h2>
        </div>
        <div className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {items.map(({ k, Icon }, i) => (
            <motion.div
              key={k}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.5, delay: (i % 4) * 0.06 }}
              className="group relative rounded-2xl border border-border bg-card p-6 transition-all hover:-translate-y-1 hover:shadow-elev"
            >
              <div className="inline-grid h-10 w-10 place-items-center rounded-lg bg-gold/15 text-gold">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="font-display mt-5 text-lg font-medium tracking-tight">
                {t(`why.items.${k}.t`)}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {t(`why.items.${k}.d`)}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}