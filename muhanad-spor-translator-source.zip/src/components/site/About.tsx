import { useTranslation } from "react-i18next";
import { motion } from "motion/react";
import { Target, Eye, Gem } from "lucide-react";
import { Eyebrow } from "./Eyebrow";
import portrait from "@/assets/muhanad-portrait.asset.json";

export function About() {
  const { t } = useTranslation();
  const cards = [
    { icon: Target, k: "mission" },
    { icon: Eye, k: "vision" },
    { icon: Gem, k: "values" },
  ] as const;

  return (
    <section id="about" className="relative py-28 sm:py-36">
      <div className="mx-auto grid max-w-7xl gap-14 px-4 sm:px-6 lg:grid-cols-[0.95fr_1.05fr] lg:gap-20">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="relative mx-auto mb-12 w-full max-w-sm lg:mx-0 lg:mb-0"
          >
            <div className="absolute -inset-6 rounded-[2.25rem] bg-gradient-to-br from-electric/30 via-royal/25 to-gold/20 opacity-70 blur-3xl" />
            <div className="relative aspect-[4/5] overflow-hidden rounded-[1.75rem] border border-white/10 bg-navy-deep shadow-elev">
              <img
                src={portrait.url}
                alt="Muhanad Spor — Professional Arabic ↔ English Translator"
                width={800}
                height={1000}
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-[1200ms] hover:scale-105"
              />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-navy-deep/80 via-transparent to-transparent" />
              <div className="pointer-events-none absolute inset-0 rounded-[1.75rem] ring-1 ring-inset ring-white/10" />
              <div className="absolute inset-x-0 bottom-0 p-6">
                <div className="font-display text-2xl font-medium text-white">Muhanad Spor</div>
                <div className="mt-1 text-[11px] uppercase tracking-[0.28em] text-gold/80">
                  Arabic ↔ English Translator
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        <div>
          <Eyebrow>{t("about.eyebrow")}</Eyebrow>
          <motion.h2
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.7 }}
            className="font-display mt-5 text-4xl font-medium leading-[1.05] tracking-tight sm:text-5xl"
          >
            {t("about.title")}
          </motion.h2>
          <div className="mt-8 space-y-5 text-[15px] leading-relaxed text-muted-foreground sm:text-base">
            <p>{t("about.p1")}</p>
            <p>{t("about.p2")}</p>
          </div>

          <div className="mt-10 grid gap-4">
          {cards.map((c, i) => (
            <motion.div
              key={c.k}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.08 }}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card p-7 shadow-soft transition-all hover:shadow-elev"
            >
              <div className="flex items-start gap-5">
                <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-navy-deep text-gold transition-transform group-hover:scale-105 dark:bg-gold/10">
                  <c.icon className="h-5 w-5" />
                </div>
                <div className="min-w-0">
                  <h3 className="font-display text-xl font-medium tracking-tight">
                    {t(`about.${c.k}`)}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {t(`about.${c.k}Text`)}
                  </p>
                </div>
              </div>
              <div className="absolute inset-x-7 bottom-0 h-px bg-gradient-to-r from-transparent via-gold/40 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
            </motion.div>
          ))}
          </div>
        </div>
      </div>
    </section>
  );
}