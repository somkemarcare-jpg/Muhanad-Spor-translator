import { useTranslation } from "react-i18next";
import { motion } from "motion/react";
import { ArrowRight } from "lucide-react";
import { Eyebrow } from "./Eyebrow";

export function LanguagePairs() {
  const { t } = useTranslation();
  const pairs = [
    { from: "English", to: "العربية", k: "en2ar" },
    { from: "العربية", to: "English", k: "ar2en" },
  ];
  return (
    <section className="relative overflow-hidden bg-navy-deep py-28 text-white sm:py-36">
      <div className="pointer-events-none absolute inset-0 opacity-[0.06] [background-image:radial-gradient(circle_at_1px_1px,white_1px,transparent_0)] [background-size:28px_28px]" />
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[460px] w-[460px] -translate-x-1/2 rounded-full bg-gold/10 blur-3xl" />
      <div className="relative mx-auto max-w-6xl px-4 sm:px-6">
        <div className="text-center">
          <Eyebrow>
            <span className="text-white/60">{t("pairs.eyebrow")}</span>
          </Eyebrow>
          <h2 className="font-display mt-5 text-4xl font-medium tracking-tight text-white sm:text-5xl">
            {t("pairs.title")}
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-base text-white/70">{t("pairs.subtitle")}</p>
        </div>

        <div className="mt-16 grid gap-5 md:grid-cols-2">
          {pairs.map((p, i) => (
            <motion.div
              key={p.k}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="group relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03] p-10 backdrop-blur transition-all hover:border-gold/40 hover:bg-white/[0.05]"
            >
              <div className="flex items-center justify-between gap-6">
                <span className="font-display text-4xl font-medium tracking-tight text-white sm:text-5xl">
                  {p.from}
                </span>
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-gold/15 text-gold transition-transform group-hover:scale-110">
                  <ArrowRight className="h-5 w-5 rtl:rotate-180" />
                </span>
                <span className="font-display text-4xl font-medium tracking-tight text-gold sm:text-5xl">
                  {p.to}
                </span>
              </div>
              <p className="mt-6 text-sm uppercase tracking-[0.2em] text-white/50">
                {t(`pairs.${p.k}`)}
              </p>
            </motion.div>
          ))}
        </div>

        <p className="mt-10 text-center text-sm text-white/50">{t("pairs.note")}</p>
      </div>
    </section>
  );
}