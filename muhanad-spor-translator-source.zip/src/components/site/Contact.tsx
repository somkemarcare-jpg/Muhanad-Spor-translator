import { useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { motion } from "motion/react";
import { Phone, MessageCircle, Mail, Upload, ArrowRight, Check } from "lucide-react";
import { Eyebrow } from "./Eyebrow";
import { SITE } from "@/lib/site";

export function Contact() {
  const { t } = useTranslation();
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [fileName, setFileName] = useState<string>("");
  const fileRef = useRef<HTMLInputElement>(null);

  const services = [
    "en2ar","ar2en","legal","medical","technical","academic","business","website","localization","proof","editing",
  ];

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    await new Promise((r) => setTimeout(r, 900));
    setSending(false);
    setSent(true);
    (e.target as HTMLFormElement).reset();
    setFileName("");
    setTimeout(() => setSent(false), 5000);
  };

  return (
    <section id="contact" className="relative overflow-hidden bg-navy-deep py-28 text-white sm:py-36">
      <div className="pointer-events-none absolute inset-0 opacity-[0.06] [background-image:radial-gradient(circle_at_1px_1px,white_1px,transparent_0)] [background-size:28px_28px]" />
      <div className="pointer-events-none absolute -right-32 top-40 h-[480px] w-[480px] rounded-full bg-gold/10 blur-3xl" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid gap-14 lg:grid-cols-[0.9fr_1.1fr] lg:gap-20">
          <div>
            <Eyebrow><span className="text-white/60">{t("contact.eyebrow")}</span></Eyebrow>
            <h2 className="font-display mt-5 text-4xl font-medium leading-[1.05] tracking-tight text-white sm:text-5xl">
              {t("contact.title")}
            </h2>
            <p className="mt-5 max-w-md text-base text-white/70">{t("contact.subtitle")}</p>

            <div className="mt-10 space-y-3">
              <a
                href={SITE.whatsapp}
                target="_blank"
                rel="noreferrer"
                className="group flex items-center justify-between gap-4 rounded-2xl border border-white/10 bg-white/[0.04] p-5 transition-colors hover:border-gold/40 hover:bg-white/[0.06]"
              >
                <span className="flex items-center gap-4">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-gold/15 text-gold">
                    <MessageCircle className="h-5 w-5" />
                  </span>
                  <span>
                    <span className="block text-sm text-white/60">{t("contact.whatsapp")}</span>
                    <span className="font-display block text-lg font-medium text-white">{SITE.phone}</span>
                  </span>
                </span>
                <ArrowRight className="h-4 w-4 text-white/40 transition-transform group-hover:translate-x-1 rtl:rotate-180 rtl:group-hover:-translate-x-1" />
              </a>
              <a
                href={`tel:${SITE.phoneRaw}`}
                className="group flex items-center justify-between gap-4 rounded-2xl border border-white/10 bg-white/[0.04] p-5 transition-colors hover:border-gold/40 hover:bg-white/[0.06]"
              >
                <span className="flex items-center gap-4">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-gold/15 text-gold">
                    <Phone className="h-5 w-5" />
                  </span>
                  <span>
                    <span className="block text-sm text-white/60">{t("contact.call")}</span>
                    <span className="font-display block text-lg font-medium text-white">{SITE.phone}</span>
                  </span>
                </span>
                <ArrowRight className="h-4 w-4 text-white/40 transition-transform group-hover:translate-x-1 rtl:rotate-180 rtl:group-hover:-translate-x-1" />
              </a>
              <a
                href={`mailto:${SITE.email}`}
                className="group flex items-center justify-between gap-4 rounded-2xl border border-white/10 bg-white/[0.04] p-5 transition-colors hover:border-gold/40 hover:bg-white/[0.06]"
              >
                <span className="flex items-center gap-4">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-gold/15 text-gold">
                    <Mail className="h-5 w-5" />
                  </span>
                  <span>
                    <span className="block text-sm text-white/60">Email</span>
                    <span className="font-display block text-lg font-medium text-white">{SITE.email}</span>
                  </span>
                </span>
                <ArrowRight className="h-4 w-4 text-white/40 transition-transform group-hover:translate-x-1 rtl:rotate-180 rtl:group-hover:-translate-x-1" />
              </a>
            </div>
          </div>

          <motion.form
            onSubmit={submit}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6 }}
            className="rounded-3xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur sm:p-8"
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={t("contact.name")}>
                <input required name="name" className={input} />
              </Field>
              <Field label={t("contact.email")}>
                <input required type="email" name="email" className={input} />
              </Field>
              <Field label={t("contact.phone")}>
                <input name="phone" className={input} />
              </Field>
              <Field label={t("contact.service")}>
                <select required name="service" defaultValue="" className={input}>
                  <option value="" disabled className="bg-navy-deep">
                    {t("contact.selectService")}
                  </option>
                  {services.map((s) => (
                    <option key={s} value={s} className="bg-navy-deep">
                      {t(`services.items.${s}.t`)}
                    </option>
                  ))}
                </select>
              </Field>
            </div>

            <div className="mt-4">
              <Field label={t("contact.message")}>
                <textarea required rows={5} name="message" className={`${input} resize-none`} />
              </Field>
            </div>

            <div className="mt-4">
              <label className="flex cursor-pointer items-center justify-between rounded-xl border border-dashed border-white/15 bg-white/[0.02] px-4 py-4 text-sm text-white/70 transition-colors hover:border-gold/40 hover:bg-white/[0.04]">
                <span className="flex items-center gap-3">
                  <Upload className="h-4 w-4 text-gold" />
                  {fileName || t("contact.file")}
                </span>
                <span className="text-xs text-white/40">PDF · DOCX · TXT</span>
                <input
                  ref={fileRef}
                  type="file"
                  className="sr-only"
                  onChange={(e) => setFileName(e.target.files?.[0]?.name ?? "")}
                />
              </label>
            </div>

            <button
              type="submit"
              disabled={sending}
              className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gold px-6 py-3.5 text-sm font-semibold text-navy-deep shadow-gold transition-transform hover:scale-[1.01] disabled:opacity-70"
            >
              {sent ? (
                <>
                  <Check className="h-4 w-4" />
                  {t("contact.success")}
                </>
              ) : sending ? (
                t("contact.sending")
              ) : (
                <>
                  {t("contact.submit")}
                  <ArrowRight className="h-4 w-4 rtl:rotate-180" />
                </>
              )}
            </button>
          </motion.form>
        </div>
      </div>
    </section>
  );
}

const input =
  "w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white placeholder:text-white/30 outline-none transition-colors focus:border-gold/60 focus:bg-white/[0.05]";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-[0.16em] text-white/50">
        {label}
      </span>
      {children}
    </label>
  );
}