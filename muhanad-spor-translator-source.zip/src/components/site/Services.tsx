import { useTranslation } from "react-i18next";
import { motion } from "motion/react";
import {
  Languages,
  ArrowLeftRight,
  Scale,
  Stethoscope,
  Cog,
  GraduationCap,
  Briefcase,
  Globe,
  MapPin,
  CheckCheck,
  PenLine,
} from "lucide-react";
import { Eyebrow } from "./Eyebrow";

const items = [
  { k: "en2ar", Icon: Languages },
  { k: "ar2en", Icon: ArrowLeftRight },
  { k: "legal", Icon: Scale },
  { k: "medical", Icon: Stethoscope },
  { k: "technical", Icon: Cog },
  { k: "academic", Icon: GraduationCap },
  { k: "business", Icon: Briefcase },
  { k: "website", Icon: Globe },
  { k: "localization", Icon: MapPin },
  { k: "proof", Icon: CheckCheck },
  { k: "editing", Icon: PenLine },
] as const;

export function Services() {
  const { t } = useTranslation();
  return (
    <section id="services" className="relative bg-muted/40 py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Eyebrow>{t("services.eyebrow")}</Eyebrow>
          <h2 className="font-display mt-5 text-4xl font-medium leading-[1.05] tracking-tight sm:text-5xl">
            {t("services.title")}
          </h2>
          <p className="mt-5 text-base leading-relaxed text-muted-foreground">
            {t("services.subtitle")}
          </p>
        </div>

        <div className="mt-16 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {items.map(({ k, Icon }, i) => (
            <motion.div
              key={k}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.5, delay: (i % 6) * 0.05 }}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card p-6 transition-all duration-300 hover:-translate-y-1 hover:border-gold/40 hover:shadow-elev"
            >
              <div className="grid h-11 w-11 place-items-center rounded-xl bg-navy-deep/5 text-navy-deep transition-colors group-hover:bg-gold/15 group-hover:text-gold dark:bg-white/5 dark:text-foreground">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="font-display mt-5 text-lg font-medium tracking-tight">
                {t(`services.items.${k}.t`)}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {t(`services.items.${k}.d`)}
              </p>
              <div className="absolute right-5 top-5 h-1.5 w-1.5 rounded-full bg-gold opacity-0 transition-opacity group-hover:opacity-100" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}