import { useTranslation } from "react-i18next";
import { motion } from "motion/react";
import { Eyebrow } from "./Eyebrow";

export function Industries() {
  const { t } = useTranslation();
  const items = t("industries.items", { returnObjects: true }) as string[];
  return (
    <section id="industries" className="py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-end lg:gap-16">
          <div>
            <Eyebrow>{t("industries.eyebrow")}</Eyebrow>
            <h2 className="font-display mt-5 text-4xl font-medium leading-[1.05] tracking-tight sm:text-5xl">
              {t("industries.title")}
            </h2>
          </div>
          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-2 xl:grid-cols-3">
            {items.map((label, i) => (
              <motion.div
                key={label}
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.45, delay: i * 0.04 }}
                className="group flex items-center justify-between rounded-xl border border-border bg-card px-5 py-4 transition-all hover:border-gold/40 hover:shadow-soft"
              >
                <span className="font-display text-base font-medium tracking-tight">{label}</span>
                <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground/30 transition-colors group-hover:bg-gold" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}