import { useTranslation } from "react-i18next";
import { motion } from "motion/react";
import { Check, ArrowRight } from "lucide-react";
import { Eyebrow } from "./Eyebrow";

const plans = ["basic", "standard", "premium"] as const;

export function Pricing() {
  const { t } = useTranslation();
  return (
    <section id="pricing" className="bg-muted/40 py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Eyebrow>{t("pricing.eyebrow")}</Eyebrow>
          <h2 className="font-display mt-5 text-4xl font-medium leading-[1.05] tracking-tight sm:text-5xl">
            {t("pricing.title")}
          </h2>
          <p className="mt-5 text-base leading-relaxed text-muted-foreground">
            {t("pricing.subtitle")}
          </p>
        </div>

        <div className="mt-16 grid gap-5 lg:grid-cols-3">
          {plans.map((p, i) => {
            const features = t(`pricing.plans.${p}.features`, { returnObjects: true }) as string[];
            const badge = i18nGet(t, `pricing.plans.${p}.badge`);
            const featured = p === "standard";
            return (
              <motion.div
                key={p}
                initial={{ opacity: 0, y: 22 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.55, delay: i * 0.08 }}
                className={`relative flex flex-col rounded-3xl border p-8 transition-all ${
                  featured
                    ? "border-transparent bg-navy-deep text-white shadow-elev lg:-translate-y-2"
                    : "border-border bg-card hover:shadow-soft"
                }`}
              >
                {badge && (
                  <span className="absolute -top-3 right-6 rounded-full bg-gold px-3 py-1 text-[10px] font-bold uppercase tracking-[0.18em] text-navy-deep rtl:left-6 rtl:right-auto">
                    {badge}
                  </span>
                )}
                <h3 className="font-display text-2xl font-medium tracking-tight">
                  {t(`pricing.plans.${p}.t`)}
                </h3>
                <p className={`mt-2 text-sm leading-relaxed ${featured ? "text-white/70" : "text-muted-foreground"}`}>
                  {t(`pricing.plans.${p}.d`)}
                </p>
                <ul className="mt-8 space-y-3 text-sm">
                  {features.map((f) => (
                    <li key={f} className="flex items-start gap-2.5">
                      <Check className={`mt-0.5 h-4 w-4 shrink-0 ${featured ? "text-gold" : "text-gold"}`} />
                      <span className={featured ? "text-white/85" : "text-foreground/85"}>{f}</span>
                    </li>
                  ))}
                </ul>
                <a
                  href="#contact"
                  className={`mt-10 inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold transition-transform hover:scale-[1.02] ${
                    featured
                      ? "bg-gold text-navy-deep shadow-gold"
                      : "border border-border bg-background text-foreground hover:border-gold/50"
                  }`}
                >
                  {t("pricing.cta")}
                  <ArrowRight className="h-4 w-4 rtl:rotate-180" />
                </a>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function i18nGet(t: (k: string) => string, key: string): string | undefined {
  const v = t(key);
  return v === key ? undefined : v;
}