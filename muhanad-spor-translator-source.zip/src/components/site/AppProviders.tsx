import { useEffect, type ReactNode } from "react";
import { I18nextProvider } from "react-i18next";
import i18n from "@/i18n";

export function AppProviders({ children }: { children: ReactNode }) {
  useEffect(() => {
    // Always dark (luxury default). Keep class for any dark: variants in shadcn.
    document.documentElement.classList.add("dark");

    // Client-only language switch (avoids SSR hydration mismatch).
    const storedLang = localStorage.getItem("ms_lang");
    if (storedLang && storedLang !== i18n.language && (storedLang === "ar" || storedLang === "en")) {
      i18n.changeLanguage(storedLang);
    }

    // i18n direction sync
    const apply = () => {
      const lng = i18n.language?.startsWith("ar") ? "ar" : "en";
      document.documentElement.lang = lng;
      document.documentElement.dir = lng === "ar" ? "rtl" : "ltr";
      localStorage.setItem("ms_lang", lng);
    };
    apply();
    i18n.on("languageChanged", apply);
    return () => {
      i18n.off("languageChanged", apply);
    };
  }, []);

  return <I18nextProvider i18n={i18n}>{children}</I18nextProvider>;
}