import { useState } from "react";
import { useTranslation } from "react-i18next";
import { motion, AnimatePresence } from "motion/react";
import { Plus } from "lucide-react";
import { Eyebrow } from "./Eyebrow";

export function Faq() {
  const { t } = useTranslation();
  const items = t("faq.items", { returnObjects: true }) as { q: string; a: string }[];
  const [open, setOpen] = useState(0);
  return (
    <section className="bg-muted/40 py-28 sm:py-36">
      <div className="mx-auto max-w-4xl px-4 sm:px-6">
        <div className="text-center">
          <Eyebrow>{t("faq.eyebrow")}</Eyebrow>
          <h2 className="font-display mt-5 text-4xl font-medium leading-[1.05] tracking-tight sm:text-5xl">
            {t("faq.title")}
          </h2>
        </div>
        <div className="mt-14 divide-y divide-border rounded-3xl border border-border bg-card">
          {items.map((it, i) => {
            const isOpen = open === i;
            return (
              <div key={i} className="px-6 sm:px-8">
                <button
                  onClick={() => setOpen(isOpen ? -1 : i)}
                  className="flex w-full items-center justify-between gap-6 py-6 text-left rtl:text-right"
                >
                  <span className="font-display text-lg font-medium tracking-tight sm:text-xl">
                    {it.q}
                  </span>
                  <span
                    className={`grid h-8 w-8 shrink-0 place-items-center rounded-full border border-border transition-all ${
                      isOpen ? "rotate-45 border-gold bg-gold text-navy-deep" : "text-muted-foreground"
                    }`}
                  >
                    <Plus className="h-4 w-4" />
                  </span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                      className="overflow-hidden"
                    >
                      <p className="pb-6 text-[15px] leading-relaxed text-muted-foreground">
                        {it.a}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}