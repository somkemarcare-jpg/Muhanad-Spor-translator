import { useTranslation } from "react-i18next";
import { Logo } from "./Logo";
import { navLinks, SITE } from "@/lib/site";
import { Linkedin, Twitter, Facebook, Instagram } from "lucide-react";

const serviceKeys = ["en2ar", "ar2en", "legal", "medical", "technical", "academic"];

export function Footer() {
  const { t } = useTranslation();
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <Logo />
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-muted-foreground">
            {t("footer.tagline")}
          </p>
          <div className="mt-6 flex items-center gap-2">
            {[Linkedin, Twitter, Facebook, Instagram].map((Icon, i) => (
              <a
                key={i}
                href="#"
                className="grid h-9 w-9 place-items-center rounded-full border border-border text-muted-foreground transition-colors hover:border-gold hover:text-gold"
                aria-label="social"
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
            {t("footer.quickLinks")}
          </h4>
          <ul className="mt-5 space-y-3 text-sm">
            {navLinks.map((l) => (
              <li key={l.id}>
                <a href={`#${l.id}`} className="text-foreground/80 transition-colors hover:text-gold">
                  {t(l.key)}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
            {t("footer.services")}
          </h4>
          <ul className="mt-5 space-y-3 text-sm">
            {serviceKeys.map((k) => (
              <li key={k}>
                <a href="#services" className="text-foreground/80 transition-colors hover:text-gold">
                  {t(`services.items.${k}.t`)}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
            {t("footer.contact")}
          </h4>
          <ul className="mt-5 space-y-3 text-sm">
            <li><a href={SITE.whatsapp} className="text-foreground/80 hover:text-gold">{SITE.phone}</a></li>
            <li><a href={`mailto:${SITE.email}`} className="text-foreground/80 hover:text-gold">{SITE.email}</a></li>
            <li className="text-muted-foreground">South Africa · Worldwide</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-4 py-6 text-xs text-muted-foreground sm:px-6">
          <p>© {new Date().getFullYear()} Muhanad Spor. {t("footer.rights")}</p>
          <div className="flex items-center gap-5">
            <a href="#" className="hover:text-gold">{t("footer.privacy")}</a>
            <a href="#" className="hover:text-gold">{t("footer.terms")}</a>
          </div>
        </div>
      </div>
    </footer>
  );
}