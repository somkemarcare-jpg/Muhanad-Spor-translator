import { useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { useInView, motion } from "motion/react";

const stats = [
  { value: 500, suffix: "+", k: "projects" },
  { value: 200, suffix: "+", k: "clients" },
  { value: 5, suffix: "+", k: "years" },
  { value: 1, suffix: "M+", k: "words" },
] as const;

function Counter({ to, suffix }: { to: number; suffix: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px", amount: 0.1 });
  const [n, setN] = useState(to);
  useEffect(() => {
    if (!inView) return;
    setN(0);
    const start = performance.now();
    const dur = 1500;
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setN(Math.round(eased * to));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, to]);
  return (
    <span ref={ref} className="font-display text-5xl font-medium tracking-tight sm:text-6xl">
      {n}
      <span className="text-gold">{suffix}</span>
    </span>
  );
}

export function Stats() {
  const { t } = useTranslation();
  return (
    <section className="border-y border-border bg-card/60 py-20">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-y-10 px-4 sm:px-6 lg:grid-cols-4">
        {stats.map((s, i) => (
          <motion.div
            key={s.k}
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.06 }}
            className="text-center"
          >
            <Counter to={s.value} suffix={s.suffix} />
            <p className="mt-3 text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">
              {t(`stats.${s.k}`)}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}