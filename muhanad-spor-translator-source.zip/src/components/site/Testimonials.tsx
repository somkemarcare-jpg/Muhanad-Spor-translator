import { useTranslation } from "react-i18next";
import { motion } from "motion/react";
import { Quote } from "lucide-react";
import { Eyebrow } from "./Eyebrow";

export function Testimonials() {
  const { t } = useTranslation();
  const items = t("testimonials.items", { returnObjects: true }) as {
    q: string;
    n: string;
    r: string;
  }[];
  return (
    <section className="py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Eyebrow>{t("testimonials.eyebrow")}</Eyebrow>
          <h2 className="font-display mt-5 text-4xl font-medium leading-[1.05] tracking-tight sm:text-5xl">
            {t("testimonials.title")}
          </h2>
        </div>

        <div className="mt-16 grid gap-5 md:grid-cols-2">
          {items.map((it, i) => (
            <motion.figure
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.55, delay: i * 0.08 }}
              className="group relative rounded-3xl border border-border bg-card p-8 shadow-soft transition-all hover:-translate-y-1 hover:shadow-elev"
            >
              <Quote className="h-7 w-7 text-gold/40" />
              <blockquote className="font-display mt-5 text-xl font-normal leading-relaxed tracking-tight text-foreground sm:text-2xl">
                "{it.q}"
              </blockquote>
              <figcaption className="mt-6 flex items-center gap-3 border-t border-border pt-5">
                <div className="grid h-10 w-10 place-items-center rounded-full bg-navy-deep font-display text-sm font-semibold text-gold">
                  {it.n.split(" ").map((s) => s[0]).slice(0, 2).join("")}
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-semibold">{it.n}</div>
                  <div className="text-xs text-muted-foreground">{it.r}</div>
                </div>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}