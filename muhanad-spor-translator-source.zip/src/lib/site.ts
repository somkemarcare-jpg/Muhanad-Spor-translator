export const SITE = {
  name: "Muhanad Spor",
  phone: "+27 63 343 4434",
  phoneRaw: "+27633434434",
  whatsapp: "https://wa.me/27633434434",
  email: "hello@muhanadspor.com",
};

export const navLinks = [
  { id: "about", key: "nav.about" },
  { id: "services", key: "nav.services" },
  { id: "industries", key: "nav.industries" },
  { id: "process", key: "nav.process" },
  { id: "pricing", key: "nav.pricing" },
  { id: "contact", key: "nav.contact" },
] as const;