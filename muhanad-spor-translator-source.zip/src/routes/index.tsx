import { createFileRoute } from "@tanstack/react-router";
import { AppProviders } from "@/components/site/AppProviders";
import { Navbar } from "@/components/site/Navbar";
import { Hero } from "@/components/site/Hero";
import { About } from "@/components/site/About";
import { Services } from "@/components/site/Services";
import { LanguagePairs } from "@/components/site/LanguagePairs";
import { Industries } from "@/components/site/Industries";
import { WhyMe } from "@/components/site/WhyMe";
import { Process } from "@/components/site/Process";
import { Stats } from "@/components/site/Stats";
import { Pricing } from "@/components/site/Pricing";
import { Testimonials } from "@/components/site/Testimonials";
import { Faq } from "@/components/site/Faq";
import { Contact } from "@/components/site/Contact";
import { Footer } from "@/components/site/Footer";
import { FloatingActions } from "@/components/site/FloatingActions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Muhanad Spor — Professional Arabic ↔ English Translator" },
      { name: "description", content: "Premium Arabic ↔ English translation services for legal, medical, technical, academic and business documents. Native bilingual quality, confidential, fast delivery." },
      { property: "og:title", content: "Muhanad Spor — Arabic ↔ English Translator" },
      { property: "og:description", content: "Precision Arabic ↔ English translation crafted by a native expert. Trusted by law firms, hospitals, universities and multinationals." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Index,
});

function Index() {
  return (
    <AppProviders>
      <div className="min-h-screen bg-background text-foreground">
        <Navbar />
        <main>
          <Hero />
          <About />
          <Services />
          <LanguagePairs />
          <Industries />
          <WhyMe />
          <Process />
          <Stats />
          <Pricing />
          <Testimonials />
          <Faq />
          <Contact />
        </main>
        <Footer />
        <FloatingActions />
      </div>
    </AppProviders>
  );
}
